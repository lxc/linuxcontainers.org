package version

// Version contains the LXD version number
var Version = "3.11"
