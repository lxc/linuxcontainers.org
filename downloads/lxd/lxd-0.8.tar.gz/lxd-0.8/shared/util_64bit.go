// +build amd64 ppc64 ppc64le arm64

package shared

const (
	btrfsSuperMagic = 0x9123683E
)
