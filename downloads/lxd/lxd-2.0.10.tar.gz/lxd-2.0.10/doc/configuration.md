# Introduction
Current LXD stores configurations for a few components:

- [Server](server.md)
- [Containers](containers.md)
- [Profiles](profiles.md)
