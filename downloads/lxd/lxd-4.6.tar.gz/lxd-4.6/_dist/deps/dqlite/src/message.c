#include "message.h"

SERIALIZE__IMPLEMENT(message, MESSAGE);
