Moved to the [website project](https://dqlite.io/docs/faq).
