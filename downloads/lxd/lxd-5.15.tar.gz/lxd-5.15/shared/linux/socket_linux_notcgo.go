//go:build linux && !cgo

package linux

const ABSTRACT_UNIX_SOCK_LEN int = 107
