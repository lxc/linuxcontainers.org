package lifecycle

import (
	"fmt"
	"net/url"

	"github.com/lxc/lxd/shared/api"
)

// ClusterGroupAction represents a lifecycle event action for cluster groups.
type ClusterGroupAction string

// All supported lifecycle events for cluster groups.
const (
	ClusterGroupCreated = ClusterGroupAction(api.EventLifecycleClusterGroupCreated)
	ClusterGroupDeleted = ClusterGroupAction(api.EventLifecycleClusterGroupDeleted)
	ClusterGroupUpdated = ClusterGroupAction(api.EventLifecycleClusterGroupUpdated)
	ClusterGroupRenamed = ClusterGroupAction(api.EventLifecycleClusterGroupRenamed)
)

// Event creates the lifecycle event for an action on a cluster group.
func (a ClusterGroupAction) Event(name string, requestor *api.EventLifecycleRequestor, ctx map[string]any) api.EventLifecycle {
	u := fmt.Sprintf("/1.0/cluster/groups/%s", url.PathEscape(name))

	return api.EventLifecycle{
		Action:    string(a),
		Source:    u,
		Context:   ctx,
		Requestor: requestor,
	}
}
