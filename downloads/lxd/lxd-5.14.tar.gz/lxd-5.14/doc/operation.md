# Manage LXD

```{toctree}
:maxdepth: 1

server
remotes
migration
architectures
```
