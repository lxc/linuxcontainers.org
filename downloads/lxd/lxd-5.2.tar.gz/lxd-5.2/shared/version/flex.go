package version

// Version contains the LXD version number
var Version = "5.2"
