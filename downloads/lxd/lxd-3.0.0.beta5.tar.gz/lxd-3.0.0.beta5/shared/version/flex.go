package version

// Version contains the LXD version number
var Version = "3.0.0.beta5"
