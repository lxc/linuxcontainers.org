//go:build !linux || !cgo || agent
// +build !linux !cgo agent

package sys
