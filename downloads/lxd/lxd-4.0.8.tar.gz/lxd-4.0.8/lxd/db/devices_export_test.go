//go:build linux && cgo && !agent
// +build linux,cgo,!agent

package db

var DeviceTypeToInt = deviceTypeToInt
