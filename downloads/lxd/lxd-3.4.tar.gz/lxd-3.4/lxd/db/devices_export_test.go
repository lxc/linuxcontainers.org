package db

var DeviceTypeToInt = dbDeviceTypeToInt
