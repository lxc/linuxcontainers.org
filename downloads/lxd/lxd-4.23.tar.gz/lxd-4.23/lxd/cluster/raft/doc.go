// Package raft contains the subset of hashicorp/raft needed to perform
// data migrations to dqlite 1.0.
package raft
