The following support resources are available to LXD users:

 - Official documentation: https://linuxcontainers.org/lxd/docs/master/
 - Community forum: https://discuss.linuxcontainers.org
 - Various howtos and blog posts: https://linuxcontainers.org/lxd/articles
 - Users mailing-list: https://lists.linuxcontainers.org/listinfo/lxc-users
 - IRC channel: [#lxc](https://kiwiirc.com/client/irc.libera.chat/#lxc) on irc.libera.chat


Commercial support for LXD can be obtained through [Canonical Ltd](https://www.canonical.com)
