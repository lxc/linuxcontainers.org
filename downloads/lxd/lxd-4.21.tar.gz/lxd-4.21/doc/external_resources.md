# External resources

```{toctree}
:maxdepth: 1

Project repository <https://github.com/lxc/lxd>
Image server <https://images.linuxcontainers.org>
```
