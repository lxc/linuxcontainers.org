// +build linux,!cgo

package shared

const ABSTRACT_UNIX_SOCK_LEN int = 107
