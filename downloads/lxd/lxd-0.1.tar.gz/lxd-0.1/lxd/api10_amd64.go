package main

const (
	btrfsSuperMagic = 0x9123683E
)
