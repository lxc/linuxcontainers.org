# Configuration
Current LXD stores configurations for a few components:

- [Server](server.md)
- [Instances](instances.md) 
- [Network](networks.md)
- [Profiles](profiles.md)
- [Storage](storage.md)
