package seccomp

// Placeholder for non-linux systems.
