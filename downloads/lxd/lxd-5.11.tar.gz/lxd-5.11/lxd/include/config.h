#ifndef CONFIG_H
#define CONFIG_H

#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1
#endif

#endif /* CONFIG_H */
