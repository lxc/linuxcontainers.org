package instance

import (
	"fmt"
)

// ErrNotImplemented is the "Not implemented" error.
var ErrNotImplemented = fmt.Errorf("Not implemented")
