package config

// DefaultVMBlockFilesystemSize is the size of a VM root device block volume's associated filesystem volume.
const DefaultVMBlockFilesystemSize = "100MiB"
