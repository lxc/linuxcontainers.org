package api

import (
	"encoding/json"
	"time"
)

// Event represents an event entry (over websocket)
type Event struct {
	Type      string          `yaml:"type" json:"type"`
	Timestamp time.Time       `yaml:"timestamp" json:"timestamp"`
	Metadata  json.RawMessage `yaml:"metadata" json:"metadata"`
}

// EventLogging represents a logging type event entry (admin only)
type EventLogging struct {
	Message string            `yaml:"message" json:"message"`
	Level   string            `yaml:"level" json:"level"`
	Context map[string]string `yaml:"context" json:"context"`
}
