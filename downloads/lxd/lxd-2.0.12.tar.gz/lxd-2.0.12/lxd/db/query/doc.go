// Package query implements helpers around database/sql to execute various
// kinds of very common SQL queries.
package query
