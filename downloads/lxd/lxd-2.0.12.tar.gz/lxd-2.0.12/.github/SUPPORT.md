The following support resources are available to LXD users:

 - Official documentation: https://lxd.readthedocs.org/en/latest
 - Community forum: https://discuss.linuxcontainers.org
 - Various howtos and blog posts: https://linuxcontainers.org/lxd/articles
 - Users mailing-list: https://lists.linuxcontainers.org/listinfo/lxc-users
 - IRC channel: #lxcontainers on irc.freenode.net


Commercial support for LXD can be obtained through [Canonical Ltd](https://www.canonical.com)
