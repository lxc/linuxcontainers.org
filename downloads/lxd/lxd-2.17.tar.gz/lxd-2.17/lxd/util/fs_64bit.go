// +build amd64 ppc64 ppc64le arm64 s390x

package util

const (
	FilesystemSuperMagicBtrfs = 0x9123683E
)
