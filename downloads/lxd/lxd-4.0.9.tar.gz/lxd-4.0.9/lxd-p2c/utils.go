package main

import (
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"io/ioutil"
	"net/url"
	"strings"

	"golang.org/x/sys/unix"
	"golang.org/x/term"

	"github.com/lxc/lxd/client"
	"github.com/lxc/lxd/lxd/migration"
	"github.com/lxc/lxd/shared"
	"github.com/lxc/lxd/shared/api"
	"github.com/lxc/lxd/shared/version"
)

func transferRootfs(dst lxd.ContainerServer, op lxd.Operation, rootfs string, rsyncArgs string) error {
	opAPI := op.Get()

	// Connect to the websockets
	wsControl, err := op.GetWebsocket(opAPI.Metadata["control"].(string))
	if err != nil {
		return err
	}

	wsFs, err := op.GetWebsocket(opAPI.Metadata["fs"].(string))
	if err != nil {
		return err
	}

	// Setup control struct
	fs := migration.MigrationFSType_RSYNC
	rsyncHasFeature := true
	header := migration.MigrationHeader{
		RsyncFeatures: &migration.RsyncFeatures{
			Xattrs:   &rsyncHasFeature,
			Delete:   &rsyncHasFeature,
			Compress: &rsyncHasFeature,
		},
		Fs: &fs,
	}

	err = migration.ProtoSend(wsControl, &header)
	if err != nil {
		protoSendError(wsControl, err)
		return err
	}

	err = migration.ProtoRecv(wsControl, &header)
	if err != nil {
		protoSendError(wsControl, err)
		return err
	}

	// Send the filesystem
	abort := func(err error) error {
		protoSendError(wsControl, err)
		return err
	}

	err = rsyncSend(wsFs, rootfs, rsyncArgs)
	if err != nil {
		return abort(err)
	}

	// Check the result
	msg := migration.MigrationControl{}
	err = migration.ProtoRecv(wsControl, &msg)
	if err != nil {
		wsControl.Close()
		return err
	}

	if !*msg.Success {
		return fmt.Errorf(*msg.Message)
	}

	return nil
}

func connectTarget(url string, certPath string, keyPath string) (lxd.ContainerServer, error) {
	var clientCrt []byte
	var clientKey []byte

	// Generate a new client certificate for this
	if certPath == "" || keyPath == "" {
		var err error

		fmt.Println("Generating a temporary client certificate. This may take a minute...")
		clientCrt, clientKey, err = shared.GenerateMemCert(true, false)
		if err != nil {
			return nil, err
		}
	} else {
		var err error

		clientCrt, err = ioutil.ReadFile(certPath)
		if err != nil {
			return nil, fmt.Errorf("Failed to read client certificate: %w", err)
		}

		clientKey, err = ioutil.ReadFile(keyPath)
		if err != nil {
			return nil, fmt.Errorf("Failed to read client key: %w", err)
		}
	}

	// Attempt to connect using the system CA
	args := lxd.ConnectionArgs{}
	args.TLSClientCert = string(clientCrt)
	args.TLSClientKey = string(clientKey)
	args.UserAgent = fmt.Sprintf("LXC-P2C %s", version.Version)
	c, err := lxd.ConnectLXD(url, &args)

	var certificate *x509.Certificate
	if err != nil {
		// Failed to connect using the system CA, so retrieve the remote certificate
		certificate, err = shared.GetRemoteCertificate(url, args.UserAgent)
		if err != nil {
			return nil, err
		}
	}

	// Handle certificate prompt
	if certificate != nil {
		digest := shared.CertFingerprint(certificate)

		fmt.Printf("Certificate fingerprint: %s\n", digest)
		fmt.Printf("ok (y/n)? ")
		line, err := shared.ReadStdin()
		if err != nil {
			return nil, err
		}

		if len(line) < 1 || line[0] != 'y' && line[0] != 'Y' {
			return nil, fmt.Errorf("Server certificate rejected by user")
		}

		serverCrt := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: certificate.Raw})
		args.TLSServerCert = string(serverCrt)

		// Setup a new connection, this time with the remote certificate
		c, err = lxd.ConnectLXD(url, &args)
		if err != nil {
			return nil, err
		}
	}

	// Get server information
	srv, _, err := c.GetServer()
	if err != nil {
		return nil, err
	}

	// Check if our cert is already trusted
	if srv.Auth == "trusted" {
		return c, nil
	}

	// Prompt for trust password
	fmt.Printf("Admin password for %s: ", url)
	pwd, err := term.ReadPassword(0)
	if err != nil {
		return nil, err
	}
	fmt.Println("")

	// Add client certificate to trust store
	req := api.CertificatesPost{
		Password: string(pwd),
	}
	req.Type = api.CertificateTypeClient

	err = c.CreateCertificate(req)
	if err != nil {
		return nil, err
	}

	return c, nil
}

func setupSource(path string, mounts []string) error {
	prefix := "/"
	if len(mounts) > 0 {
		prefix = mounts[0]
	}

	// Mount everything
	for _, mount := range mounts {
		target := fmt.Sprintf("%s/%s", path, strings.TrimPrefix(mount, prefix))

		// Mount the path
		err := unix.Mount(mount, target, "none", unix.MS_BIND, "")
		if err != nil {
			return fmt.Errorf("Failed to mount %s: %v", mount, err)
		}

		// Make it read-only
		err = unix.Mount("", target, "none", unix.MS_BIND|unix.MS_RDONLY|unix.MS_REMOUNT, "")
		if err != nil {
			return fmt.Errorf("Failed to make %s read-only: %v", mount, err)
		}
	}

	return nil
}

func parseURL(URL string) (string, error) {
	u, err := url.Parse(URL)
	if err != nil {
		return "", err
	}

	// Create a URL with scheme and hostname since it wasn't provided
	if u.Scheme == "" && u.Host == "" && u.Path != "" {
		u, err = url.Parse(fmt.Sprintf("https://%s", u.Path))
		if err != nil {
			return "", err
		}
	}

	// If no port was provided, use default port
	if u.Port() == "" {
		u.Host = fmt.Sprintf("%s:%d", u.Hostname(), shared.HTTPSDefaultPort)
	}

	return u.String(), nil
}
