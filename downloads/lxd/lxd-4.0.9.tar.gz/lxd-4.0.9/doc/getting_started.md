# Getting started

In addition to the documentation in this section, see the [Getting Started guide](https://linuxcontainers.org/lxd/getting-started-cli/) on the website.

```{toctree}
:maxdepth: 1

requirements
installing
Frequently asked <faq>
security
contributing
support
```
