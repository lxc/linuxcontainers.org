# Configuration
LXD stores the configuration for the following components:

```{toctree}
:maxdepth: 1

containers
Instances <instances>
Networks <networks>
Preseed files <preseed>
profiles
Projects <projects>
Server settings <server>
Storage pools <storage>
Virtual machines <virtual-machines>
```
