package version

// Version contains the LXD version number
var Version = "4.0.9"
