//go:build !linux || !cgo || agent

package sys
