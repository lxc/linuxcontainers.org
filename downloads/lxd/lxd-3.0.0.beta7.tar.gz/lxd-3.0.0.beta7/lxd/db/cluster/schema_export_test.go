package cluster

var FreshSchema = freshSchema
