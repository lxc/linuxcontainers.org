# Manage LXD

```{toctree}
:maxdepth: 1

server
projects
remotes
explanation/performance_tuning
Backups <backup>
migration
```
