/* This is a FLEXible file which can be used by both client and daemon.
 * Teehee.
 */
package version

var Version = "2.0.9"
var UserAgent = "LXD " + Version

/*
 * Please increment the api compat number every time you change the API.
 *
 * Version 1.0: ping
 */
var APIVersion = "1.0"
