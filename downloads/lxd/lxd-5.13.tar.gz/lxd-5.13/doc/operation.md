# Manage LXD

```{toctree}
:maxdepth: 1

server
remotes
explanation/performance_tuning
Backups <backup>
migration
architectures
```
