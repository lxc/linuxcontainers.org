---
relatedlinks: https://linuxcontainers.org/lxd/getting-started-cli/,https://www.youtube.com/watch?v=QyXOOE_4cm0
---

# Getting started

In addition to the documentation in this section, see the [Getting Started guide](https://linuxcontainers.org/lxd/getting-started-cli/) on the website.

```{toctree}
:maxdepth: 1

requirements
Install LXD <installing>
Initialize LXD <howto/initialize>
Frequently asked <faq>
contributing
support
```
