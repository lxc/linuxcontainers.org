---
relatedlinks: https://ubuntu.com/tutorials/introduction-to-lxd-projects
---

(projects)=
# Projects

```{toctree}
:maxdepth: 1

explanation/projects
Create and configure projects <howto/projects_create>
Work with different projects <howto/projects_work>
Confine projects to users <howto/projects_confine>
reference/projects
```
