# Introduction
Current LXD stores configurations for a few components:

- [Server](server.md)
- [Containers](containers.md) 
- [Network](networks.md)
- [Profiles](profiles.md)
- [Storage](storage.md)
