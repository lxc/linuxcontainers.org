// +build amd64 ppc64 ppc64le arm64

package main

const (
	filesystemSuperMagicBtrfs = 0x9123683E
)
