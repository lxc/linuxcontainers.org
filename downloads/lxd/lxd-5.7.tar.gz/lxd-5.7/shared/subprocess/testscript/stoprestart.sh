#!/bin/sh
echo "hello again"
echo "waiting now"

sleep 5
