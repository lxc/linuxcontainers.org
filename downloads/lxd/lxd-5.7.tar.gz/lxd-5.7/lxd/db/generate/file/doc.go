// Package file contains helpers to write auto-generated Go source files.
package file
