package db

// Directive for regenerating both the cluster and node database schemas.
//
//go:generate lxd-generate db schema
