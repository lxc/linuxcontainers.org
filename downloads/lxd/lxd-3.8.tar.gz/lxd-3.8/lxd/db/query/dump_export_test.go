package query

var DumpTable = dumpTable
var DumpParseSchema = dumpParseSchema
var DumpSchemaTable = dumpSchemaTable
