package cluster

// TLSClientConfig is used to generate TLS client configurations in unit tests.
var TLSClientConfig = tlsClientConfig
