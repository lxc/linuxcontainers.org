all
exclude_rule 'MD013'
exclude_rule 'MD046'
exclude_rule 'MD041'
exclude_rule 'MD040'
exclude_rule 'MD024'
exclude_rule 'MD033'
exclude_rule 'MD022'
exclude_rule 'MD031'
rule 'MD026', :punctuation => '.,;:!'
rule 'MD003', :style => :atx
