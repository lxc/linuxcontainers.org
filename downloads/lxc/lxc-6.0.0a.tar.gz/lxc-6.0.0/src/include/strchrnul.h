/* SPDX-License-Identifier: LGPL-2.1+ */

#include "../lxc/compiler.h"

__hidden extern char *strchrnul(const char *s, int c_in);
