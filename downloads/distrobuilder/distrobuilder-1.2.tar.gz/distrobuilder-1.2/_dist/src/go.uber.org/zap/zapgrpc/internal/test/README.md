This submodule exists to test zapgrpc against grpc-go without adding a
dependency on grpc-go to Zap.
