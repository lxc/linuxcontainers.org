package version

// Version contains the distrobuilder version number
var Version = "1.3"
