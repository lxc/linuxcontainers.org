package sources

import (
	"fmt"
	"net/url"
	"path"
	"path/filepath"
	"strconv"
	"strings"

	lxd "github.com/lxc/lxd/shared"
	"github.com/pkg/errors"
	"gopkg.in/antchfx/htmlquery.v1"

	"github.com/lxc/distrobuilder/shared"
)

type plamolinux struct {
	common
}

// Run downloads Plamo Linux.
func (s *plamolinux) Run() error {
	releaseStr := strings.TrimSuffix(s.definition.Image.Release, ".x")

	release, err := strconv.Atoi(releaseStr)
	if err != nil {
		return errors.Wrapf(err, "Failed to convert %q", releaseStr)
	}

	u, err := url.Parse(s.definition.Source.URL)
	if err != nil {
		return errors.Wrapf(err, "Failed to parse %q", s.definition.Source.URL)
	}

	mirrorPath := path.Join(u.Path, fmt.Sprintf("Plamo-%s.x", releaseStr),
		s.definition.Image.ArchitectureMapped, "plamo")

	paths := []string{path.Join(mirrorPath, "00_base")}
	ignoredPkgs := []string{"alsa_utils", "grub", "kernel", "lilo", "linux_firmware", "microcode_ctl",
		"linux_firmwares", "cpufreqd", "cpufrequtils", "gpm", "ntp", "kmod", "kmscon"}

	if release < 7 {
		paths = append(paths, path.Join(mirrorPath, "01_minimum"))
	}

	var pkgDir string

	for _, p := range paths {
		u.Path = p

		pkgDir, err = s.downloadFiles(s.definition.Image, u.String(), ignoredPkgs)
		if err != nil {
			return errors.Wrap(err, "Failed to download packages")
		}
	}

	var pkgTool string

	// Find package tool
	if release < 7 {
		pkgTool = "hdsetup"
	} else {
		pkgTool = "pkgtools7"
	}

	matches, err := filepath.Glob(filepath.Join(pkgDir, fmt.Sprintf("%s-*.txz", pkgTool)))
	if err != nil {
		return errors.Wrap(err, "Failed to match pattern")
	}

	if len(matches) == 0 {
		return errors.New("Couldn't find any matching package")
	} else if len(matches) > 1 {
		return errors.New("Found more than one matching package")
	}

	err = shared.RunCommand("tar", "-pxJf", matches[0], "-C", pkgDir, "sbin/")
	if err != nil {
		return errors.Wrapf(err, "Failed to unpack %q", matches[0])
	}

	rootfsDirAbs, err := filepath.Abs(s.rootfsDir)
	if err != nil {
		return errors.Wrap(err, "Failed to get absolute path")
	}

	err = shared.RunScript(fmt.Sprintf(`#!/bin/sh
set -eux

# Input variables
PKG_DIR="%s"
ROOTFS_DIR="%s"

# Environment
export PATH="${PKG_DIR}/sbin:${PATH}"
export LC_ALL="C"
export LANG="C"

# Fix name of installer directory
if [ -d "${PKG_DIR}/sbin/installer_new" ]; then
    [ -d "${PKG_DIR}/sbin/installer" ] && rm -r "${PKG_DIR}/sbin/installer"
    mv "${PKG_DIR}/sbin/installer_new" "${PKG_DIR}/sbin/installer"
fi

# Don't call ldconfig
sed -i "/ldconfig/!s@/sbin@${PKG_DIR}&@g" ${PKG_DIR}/sbin/installpkg*

# Don't override PATH
sed -i "/^export PATH/d" ${PKG_DIR}/sbin/installpkg*

# Install all packages
for pkg in $(ls -cr ${PKG_DIR}/*.t?z); do
    installpkg -root ${ROOTFS_DIR} -priority ADD ${pkg}
done
`, pkgDir, rootfsDirAbs))
	if err != nil {
		return errors.Wrap(err, "Failed to run script")
	}

	return nil
}

func (s *plamolinux) downloadFiles(def shared.DefinitionImage, URL string, ignoredPkgs []string) (string, error) {
	doc, err := htmlquery.LoadURL(URL)
	if err != nil {
		return "", errors.Wrapf(err, "Failed to load URL %q", URL)
	}

	if doc == nil {
		return "", errors.New("Empty HTML document")
	}

	nodes := htmlquery.Find(doc, `//a/@href`)

	var dir string

	for _, n := range nodes {
		target := htmlquery.InnerText(n)

		if strings.HasSuffix(target, ".txz") {
			pkgName := strings.Split(target, "-")[0]
			if lxd.StringInSlice(pkgName, ignoredPkgs) {
				continue
			}

			// package
			dir, err = shared.DownloadHash(def, fmt.Sprintf("%s/%s", URL, target), "", nil)
			if err != nil {
				return "", errors.Wrapf(err, "Failed to download %q", fmt.Sprintf("%s/%s", URL, target))
			}
		} else if strings.HasSuffix(target, ".txz/") {
			// directory
			u, err := url.Parse(URL)
			if err != nil {
				return "", errors.Wrapf(err, "Failed to parse %q", URL)
			}

			u.Path = path.Join(u.Path, target)

			return s.downloadFiles(def, u.String(), ignoredPkgs)
		}
	}

	return dir, nil
}
