package version

// Version contains the distrobuilder version number.
var Version = "3.1"
