# Command line options

% Include content from [../../README.md](../../README.md)
```{include} ../../README.md
   :start-after: <!-- Include start CLI -->
   :end-before: <!-- Include end CLI -->
```
