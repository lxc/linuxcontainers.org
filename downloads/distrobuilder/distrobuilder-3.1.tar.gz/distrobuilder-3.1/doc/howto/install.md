# How to install `distrobuilder`

% Include content from [../../README.md](../../README.md)
```{include} ../../README.md
   :start-after: <!-- Include start installing -->
   :end-before: <!-- Include end installing -->
```
