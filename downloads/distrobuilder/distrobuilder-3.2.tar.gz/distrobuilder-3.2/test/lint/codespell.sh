#!/bin/sh -eu
codespell -I .codespell-ignore distrobuilder doc generators image managers shared sources test windows
