package version

// Version contains the distrobuilder version number
var Version = "2.0"
