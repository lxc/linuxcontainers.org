TODO:

* What are tags?
* List+explain all existing tags (pongo2 + pongo2-addons)

Implemented tags so far which needs documentation:

* autoescape
* block
* comment
* cycle
* extends
* filter
* firstof
* for
* if
* ifchanged
* ifequal
* ifnotequal
* import
* include
* lorem
* macro
* now
* set
* spaceless
* ssi
* templatetag
* verbatim
* widthratio
* with